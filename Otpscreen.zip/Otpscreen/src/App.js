import React from 'react'
import UserProfileInterface from './components/UserProfile/UserProfileInterface'
const App = () => {
  return (
    <div>
        <UserProfileInterface/>
    </div>
  )
}

export default App
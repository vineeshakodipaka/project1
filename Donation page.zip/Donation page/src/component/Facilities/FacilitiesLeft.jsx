import React from 'react'

function FacilitiesLeft() {
  return (
    <div>FacilitiesLeft</div>
  )
}

export default FacilitiesLeft